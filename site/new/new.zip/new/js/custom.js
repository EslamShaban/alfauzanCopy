/*global $*/

$(function () {

    "use strict";
    
/* ------------------------------------------------------------*/
/* --- 0. Section ---------------------------------------------*/
/* ------------------------------------------------------------*/

    $(".slider").owlCarousel({
        rtl: true,
        items: 1,
        loop: true,
        margin: 5,
        autoplay: true,
        autoplayHoverPause: true,
        navSpeed: 2000 / true,
        autoplaySpeed: 2000 / true
    });
    
});