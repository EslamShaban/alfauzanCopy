<?php

	namespace App\Models;

	use Illuminate\Database\Eloquent\Model;
	use Illuminate\Database\Eloquent\SoftDeletes;

	class Category extends Model
	{
		use SoftDeletes;

		protected $table = 'categories';

		protected $dates = ['deleted_at'];

		public function ads()
		{

			return $this->hasMany( 'App\Models\Ads', 'category_id' );
		}

		public function project()
		{

			return $this->hasMany( 'App\Models\Project', 'category_id' );
		}
	}
