<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Html extends Model
{
    protected $table = 'html';
}
