<?php

	namespace App\Models;

	use Illuminate\Database\Eloquent\Model;

	class SmsEmailNotification extends Model
	{
		protected $table = 'smsemailnotification';
	}
