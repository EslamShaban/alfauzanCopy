<?php

	namespace App\Http\Controllers\dashboard;

	use App\Http\Controllers\Controller;
	use App\Models\Job;
	use Illuminate\Http\Request;
	use Session;

	class HomeController extends Controller
	{

		/************ Job applicants ***********/

		public function jobs()
		{
			$jobs = Job::latest()->get();
			//return $jobs;
			return view( 'dashboard.jobs.index', compact( 'jobs' ) );

		}

		/************ delete job ***********/

		public function deleteJob( Request $request )
		{
			//check if job exist
			$job = Job::findOrFail( $request->id );

			$job->delete();

			Session::flash( 'success', 'تم حذف طلب العمل' );
			return back();

		}
	}
