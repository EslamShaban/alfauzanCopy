<?php

	namespace App\Http\Controllers\dashboard;

	use App\Http\Controllers\Controller;
	use App\Models\Ads;
	use App\Models\Category;
	use App\Models\Chat;
	use App\Models\Project;
	use App\User;
	use File;
	use Illuminate\Http\Request;
	use Illuminate\Support\Facades\Auth;
	use Illuminate\Support\Facades\DB;
	use Image;
	use Session;

	class AdsController extends Controller
	{

		/************ ordnary ads ***********/

		public function ads()
		{
			$ads = Ads::where( 'offer', 0 )->get();

			//get  ordinary  categories
			$categories = Category::where( 'offer', 0 )->get();

			//get all projects
			$projects = Project::get();

			//return $ads[0]->image;
			return view( 'dashboard.ads.ads', compact( 'ads', 'projects', 'categories' ) );

		}

		/************ offerd ads ***********/

		public function offerAds()
		{
			$ads = Ads::where( 'offer', 1 )->get();

			//get all categories
			$categories = Category::where( 'offer', 1 )->get();

			//return $ads[0]->image;
			return view( 'dashboard.ads.offer', compact( 'ads', 'categories' ) );

		}


		/************ add ad ***********/

		public function addAd( Request $request )
		{
			//return $request->all();
			//make validation
			$this->validate( $request,
			                 [
				                 'avatar'    => 'required',
				                 'name_ar'   => 'required',
				                 'name_en'   => 'required',
				                 'cost'      => 'required',
				                 'tax'       => 'required',
				                 'vat'       => 'required',
				                 'code'      => 'required|unique:ads',
				                 'category'  => 'required|exists:categories,id',
				                 'video'     => 'required',
				                 'desc'      => 'required',
				                 'details'   => 'required',
				                 'component' => 'required',
				                 'lat'       => 'required',
				                 'lng'       => 'required',
			                 ], [
				                 'avatar.required'    => 'ادخل صور الاعلان',
				                 'name_ar.required'   => 'ادخل الاسم العربى',
				                 'name_en.required'   => 'ادخل الاسم بالانجليزى',
				                 'cost.required'      => 'ادخل السعر',
				                 'tax.required'       => 'ادخل الضريبة',
				                 'vat.required'       => 'ادخل السعى',
				                 'code.required'      => 'ادخل كود العرض',
				                 'code.unique'        => 'كود العرض غير متاح',
				                 'video.required'     => 'ادخل رايظ الفيديو',
				                 'desc.required'      => 'ادخل الوصف',
				                 'details.required'   => 'ادخل التفاصيل',
				                 'component.required' => 'ادخل المكونات',
				                 'lat.required'       => 'ادخل العنوان',
				                 'lng.required'       => 'ادخل العنوان',
				                 'category.required'  => 'اختر القسم',
				                 'category.exists'    => 'القسم غير موجود',
			                 ] );

			//add data to database
			$ad              = new Ads();
			$ad->name_en     = $request->name_en;
			$ad->name_ar     = $request->name_ar;
			$ad->cost        = $request->cost;
			$ad->tax         = $request->tax;
			$ad->vat         = $request->vat;
			$ad->code        = $request->code;
			$ad->video       = $request->name_ar;
			$ad->desc        = $request->video;
			$ad->details     = $request->details;
			$ad->component   = $request->component;
			$ad->lat         = $request->lat;
			$ad->lng         = $request->lng;
			$ad->category_id = $request->category;
			$ad->user_id     = Auth::id();

			if ($request->has( 'project' ) && $request->project != null)
				$ad->project_id = $request->project;

			if ($request->has( 'type' ) && $request->type != null)
				$ad->offer = 1;


			$ad->save();

			//add images to database

			if ($request->hasFile( 'avatar' )) {

				$x = Array(150, 190, 200, 220, 250, 270, 300, 320, 350, 370, 400, 470, 450, 500, 550, 520, 420, 410,
				           600);

				$images          = $request->file( 'avatar' );
				$destinationPath = '../dashboard/uploads/ads';

				foreach ($images as $im) {
					$imgName = str_random( 10 ) . '.' . 'png';
					$imgs    = Image::make( $im );
					$imgs->resize( 400, 350 )->save( $destinationPath . '/' . $imgName );
					$photo         = new \App\Models\Image();
					$photo->ads_id = $ad->id;
					$photo->image  = $imgName;
					$photo->save();
				}
			}

			Session::flash( 'success', 'تم إضافة الاعلان' );
			return back();

		}

		/************ update ad ***********/

		public function updateAd( Request $request )
		{

			//make validation
			$this->validate( $request,
			                 [
				                 'category' => 'exists:categories,id',
			                 ], [
				                 'category.exists' => 'القسم غير موجود',
			                 ] );


			//check if project exist
			$ad = Ads::findOrFail( $request->id );

			//arabic name
			if ($request->edit_name_ar) {
				$ad->name_ar = $request->edit_name_ar;
			}

			//english name
			if ($request->edit_name_en) {
				$ad->name_en = $request->edit_name_en;
			}

			//category
			if ($request->edit_category) {
				$ad->category_id = $request->edit_category;
			}

			//lat
			if ($request->edit_lat) {
				$ad->lat = $request->edit_lat;
			}

			//lng
			if ($request->edit_lng) {
				$ad->lng = $request->edit_lng;
			}

			//cost
			if ($request->edit_cost) {
				$ad->cost = $request->edit_cost;
			}

			//tax
			if ($request->edit_tax) {
				$ad->tax = $request->edit_tax;
			}

			//vat
			if ($request->edit_vat) {
				$ad->vat = $request->edit_vat;
			}

			//code
			if ($request->edit_code) {
				$ad->code = $request->edit_code;
			}

			//video
			if ($request->edit_video) {
				$ad->video = $request->edit_video;
			}

			//desc
			if ($request->edit_desc) {
				$ad->desc = $request->edit_desc;
			}

			//component
			if ($request->edit_component) {
				$ad->component = $request->edit_component;
			}

			//details
			if ($request->edit_details) {
				$ad->details = $request->edit_details;
			}

			//project
			if ($request->edit_project != null) {
				$ad->project = $request->edit_project;
			}

			$ad->save();

			Session::flash( 'success', 'تم حفظ الاعلان' );
			return back();
		}


		/************ all image ***********/

		public function images( $id )
		{
			//check id ad is exist
			$ad = Ads::findOrFail( $id );

			$images = \App\Models\Image::where( 'ads_id', $ad->id )->get();

			return view( 'dashboard.ads.images', compact( 'images', 'ad' ) );
		}

		/************ add image ***********/

		public function addImage( Request $request )
		{
			//return $request->all();
			$ad = Ads::findOrFail( $request->ad_id );

			if ($request->hasFile( 'images' )) {

				//set destination path
				$images          = $request->images;
				$destinationPath = '../dashboard/uploads/ads';

				foreach ($images as $im) {
					$imgName = str_random( 10 ) . '.' . 'png';
					$imgs    = Image::make( $im );
					$imgs->save( $destinationPath . '/' . $imgName );
					$photo         = new \App\Models\Image();
					$photo->ads_id = $ad->id;
					$photo->image  = $imgName;
					$photo->save();
				}

				Session::flash( 'success', 'تم إضافة  صور الاعلان' );
				return back();
			}
		}

		/************ delete image ***********/

		public function deleteImage( Request $request )
		{
			//check if image exist
			$img = \App\Models\Image::findOrFail( $request->id );

			//check if it last image
			$imgs_num = \App\Models\Image::where( 'ads_id', $img->ads_id )->count();
			if ($imgs_num <= 1)
				return response()->json( ['status' => 0] );

			File::delete( 'dashboard/uploads/ads/' . $img->image );
			$img->delete();
			return response()->json( ['status' => 1] );
		}

		/************ delete project ***********/
		public function deleteAd( Request $request )
		{
			//check if ad exist
			$ad = Ads::findOrFail( $request->id );

			//delete project images
			$images = \App\Models\Image::where( 'ads_id', $ad->id )->get();
			foreach ($images as $image) {
				File::delete( '/dashboard/uploads/ads/' . $image->image );
				$image->delete();
			}
			$ad->delete();

			Session::flash( 'success', 'تم حذف الاعلان' );
			return back();
		}

		/************ ad rooms ***********/
		public function rooms( $id )
		{
			//check if ad exist
			$ad = Ads::findOrFail( $id );

			//get chat rooms for this ads
			$chat_id = Chat::select( DB::raw( 'max(id) as lid' ) )
			               ->where( 's_id', Auth::id() )
			               ->orWhere( 'r_id', Auth::id() )
			               ->groupBy( 'room' )
			               ->orderBy( 'lid', 'desc' )
			               ->pluck( 'lid' )->toArray();

			$rooms = Chat::whereIn( 'id', $chat_id )
			             ->get();


			//			return $rooms;
			return view( 'dashboard.ads.chat', compact( 'rooms' ) );

		}

		/************ get room messages ***********/
		public function chat( $room )
		{

			//get all msgs in this room
			$msgs = Chat::where( 'room', $room )->get();

			//set every msg if it sent or recived
			foreach ($msgs as $msg) {
				if ($msg->s_id == Auth::id())
					$msg->type = 'out';
				else
					$msg->type = 'in';
			}

			$msgs = view( 'dashboard.ads.msgs', compact( 'msgs' ) )->render();
			return response( $msgs );
		}

		/************ send messages ***********/
		public function send( Request $request )
		{

			//make validation
//			$this->validate( $request, [
//				'other_id' => 'required',
//				'ads_id'   => 'required',
//				'message'  => 'required',
//				'room'     => 'required',
//			] );

			//check if ads exist
			Ads::findorFail( $request->ads_id );

			//check if other user is exist
			User::findOrFail( $request->other_id );

			//send message
			$msg          = new Chat();
			$msg->message = $request->message;
			$msg->room    = $request->room;
			$msg->s_id    = Auth::id();
			$msg->r_id    = $request->other_id;
			$msg->ads_id  = $request->ads_id;
			$msg->save();

			$msg = view( 'dashboard.ads.msgs', compact( 'msg' ) )->render();
			return response( $msg );
		}

	}
