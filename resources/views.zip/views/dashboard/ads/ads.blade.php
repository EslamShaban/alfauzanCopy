@extends('dashboard.layout.master')


<!-- style -->
@section('style')
	<style type = "text/css">

		.profile-img-container {
			padding: 4px;

			border-color: currentColor;
			width: 250px;
			height: 304px;
		}

		.profile-img-container {
			position: relative;
			display: inline-block; /* added */
			overflow: hidden; /* added */
		}

		/*
			   .profile-img-container img {width:100%;} !* remove if using in grid system *!
		*/

		.profile-img-container img:hover {
			opacity: 0.5
		}

		.profile-img-container:hover a {
			opacity: 1; /* added */
			top: 0; /* added */
			z-index: 500;
		}

		/* added */
		.profile-img-container:hover a span {
			top: 50%;
			position: absolute;
			left: 0;
			right: 0;
			transform: translateY(-50%);
		}

		/* added */
		.profile-img-container a {
			display: block;
			position: absolute;
			top: -100%;
			opacity: 0;
			left: 0;
			bottom: 0;
			right: 0;
			text-align: center;
			color: inherit;
		}

		.modal .icon-camera {
			font-size: 100px;
			color: #797979
		}

		.modal input {
			margin-bottom: 4px
		}

		.reset {
			border: none;
			background: #fff;
			margin-right: 11px;
		}

		.icon-trash {
			margin-left: 8px;
			color: red;
		}

		.dropdown-menu {
			min-width: 88px;
		}

		#hidden {
			display: none;
		}

	</style>
@endsection
<!-- /style -->
@section('content')
	<div class = "panel panel-flat">
		<div class = "panel-heading">
			<h5 class = "panel-title">قائمة الاعلانات</h5>
			<div class = "heading-elements">
				<ul class = "icons-list">
					<li><a data-action = "collapse"></a></li>
					<li><a data-action = "reload"></a></li>
				</ul>
			</div>
		</div>

		<!-- buttons -->
		<div class = "panel-body">
			<div class = "row">
				<div class = "col-xs-3">
					<button class = "btn bg-blue btn-block btn-float btn-float-lg openAddModal"
					        onclick = "initialize()" type = "button" data-toggle = "modal"
					        data-target = "#exampleModal"><i class = "icon-plus3"></i> <span>اضافة اعلان</span>
					</button>
				</div>
				<div class = "col-xs-3">
					<button class = "btn bg-purple-300 btn-block btn-float btn-float-lg" type = "button"><i
							   class = "icon-list-numbered"></i> <span>عدد الاعلانات: {{count($ads)}} </span>
					</button>
				</div>
				<div class = "col-xs-3">
					<a href = "{{route('offer_ads')}}"
					   class = "btn bg-teal-400 btn-block btn-float btn-float-lg correspondent">
						<i class = " icon-station"></i> <span>الاعلانات المميزة</span>
					</a>
				</div>
				<div class = "col-xs-3">
					<a href = "{{route('logout')}}" class = "btn bg-warning-400 btn-block btn-float btn-float-lg"
					   type = "button"><i class = "icon-switch"></i> <span>خروج</span></a>
				</div>

			</div>
		</div>
		<!-- /buttons -->

		<table class = "table datatable-basic">
			<thead>
			<tr>
				<th>الصوره</th>
				<th>الاسم</th>
				<th>السعر</th>
				<th>التقييم</th>
				<th>عدد المشاهدات</th>
				<th>الوصف</th>
				<th>المستخدم</th>
				<th>البريد الإلكترونى</th>
				<th>المحادثات</th>
				<th>صور المنتج</th>
				<th>تاريخ الاضافه</th>
				<th>التحكم</th>
			</tr>
			</thead>
			<tbody>
			@foreach($ads as $ad)

				<script>

				</script>
				<tr>
					<td><img src = "{{asset('dashboard/uploads/ads/'.$ad->image[0]->image)}}"
					         style = "width:40px;height: 40px" class = "img-circle" alt = ""></td>
					<td>{{$ad->name_ar}}</td>
					<td>{{$ad->cost}}</td>
					<td>{{rate($ad->id)}}</td>
					<td>{{count($ad->view)}}</td>
					<td>{{$ad->desc}}</td>
					<td>{{$ad->user->name}}</td>
					<td>{{$ad->user->email}}</td>
					<td>
						@if(count($ad->chat))
							<a href = "{{route('ad_rooms',[$ad->id])}}">كل المحادثات</a>
						@else
							لا يوجد محادثات
						@endif
					</td>
					<td><a class = "glyphicon glyphicon-th" href = "{{route('ad_images', $ad->id)}}"> </a></td>
					<td>{{$ad->created_at->diffForHumans()}}</td>
					<td>
						<ul class = "icons-list">
							<li class = "dropdown">
								<a href = "#" class = "dropdown-toggle" data-toggle = "dropdown">
									<i class = "icon-menu9"></i>
								</a>

								<ul class = "dropdown-menu dropdown-menu-right">
									<!-- edit button -->
									<li>
										<a href = "#"
										   onclick = "initializeEdit({{$ad}})"
										   data-toggle = "modal" data-target = "#exampleModal2"
										   class = "openEditmodal">
											<i class = "icon-pencil7"></i>تعديل
										</a>
									</li>


									<!-- delete button -->
									<form action = "{{route('delete_ad')}}" method = "POST">
										{{csrf_field()}}
										<input type = "hidden" name = "id" value = "{{$ad->id}}">
										<li>
											<button type = "submit" class = "generalDelete reset"><i
													   class = "icon-trash"></i>حذف
											</button>
										</li>
									</form>
								</ul>
							</li>
						</ul>
					</td>
				</tr>
			@endforeach
			</tbody>
		</table>

		<!-- Add ad Modal -->
		<div class = "modal fade" id = "exampleModal" tabindex = "-1" role = "dialog"
		     aria-labelledby = "exampleModalLabel" aria-hidden = "true">
			<div class = "modal-dialog" role = "document">
				<div class = "modal-content">
					<div class = "modal-header">
						<h5 class = "modal-title" id = "exampleModalLabel">أضافة اعلان جديد</h5>
					</div>
					<div class = "modal-body">
						<div class = "row">
							<form action = "{{route('add_ad')}}" method = "POST"
							      enctype = "multipart/form-data">
								{{csrf_field()}}

								<div class = "row">
									<div class = "col-sm-3 text-center">
										<label style = "margin-bottom: 0">اختيار صور الاعلان</label>
										<i class = "icon-camera" onclick = "addChooseFile()"
										   style = "cursor: pointer;"></i>
										<div class = "images-upload-block">
											<input type = "file" name = "avatar[]" multiple>
										</div>
									</div>
									<div class = "col-sm-9" style = "margin-top: 20px">
										<input type = "text" name = "name_ar" id = "address"
										       class = "form-control" placeholder = "الاسم العربى"
										       style = "margin-bottom: 10px">
										<input type = "text" name = "name_en" id = "address"
										       class = "form-control" placeholder = "الاسم الانجليزى"
										       style = "margin-bottom: 10px">

									</div>
								</div>

								<div class = "row">
									<div class = "col-sm-6">
										<input type = "number" name = "cost" class = "form-control"
										       placeholder = "السعر ">
										<select name = "category" class = "form-control"
										        style = "margin-bottom: 5px">
											<option>-- إختر القسم --</option>
											@foreach($categories as $category)
												<option value = "{{$category->id}}">{{$category->name_ar}}</option>
											@endforeach
										</select>
										<select name = "project" class = "form-control"
										        style = "margin-bottom: 5px">
											<option>--إختر المخطط --</option>
											@foreach($projects as $project)
												<option value = "{{$project->id}}">{{$project->name_ar}}</option>
											@endforeach
										</select>
									</div>

									<div class = "col-sm-6">
										<input type = "number" name = "tax" class = "form-control"
										       placeholder = "الضريبة">
										<input type = "number" name = "vat" class = "form-control"
										       placeholder = "السعى">
										<input type = "text" name = "code" class = "form-control"
										       placeholder = "كود العرض ">
									</div>

									<div class = "col-sm-12">
										<input type = "text" name = "video" class = "form-control"
										       placeholder = "رابط الفيديو">

									</div>
									<div class = "col-sm-12">
										<textarea
											   style = "margin-bottom: 5px"
											   class = "form-control" id = "desc" name = "desc" rows = "2"
											   placeholder = "وصف قصير"></textarea>

									</div>
									<div class = "col-sm-12">
										<textarea
											   style = "margin-bottom: 5px"
											   class = "form-control" id = "component" name = "component"
											   rows = "2"
											   placeholder = "المكونات"></textarea>

									</div>
									<div class = "col-sm-12">
										<textarea
											   style = "margin-bottom: 5px"
											   class = "form-control" id = "details" name = "details"
											   rows = "8"
											   placeholder = "التفاصيل"></textarea>

									</div>

									<input type = "hidden" name = "lat" id = "lat"
									       value = "14.4855648" readonly>


									<input type = "hidden" name = "lng" id = "lng"
									       value = "12.4855648" readonly>

									<div class = "row">
										<div class = "col-sm-12"
										     style = "width: 500px; height: 300px; margin-right: 60px"
										     id = "add_map">
										</div>
									</div>


								</div>

								<div class = "col-sm-12" style = "margin-top: 10px">
									<button type = "submit" class = "btn btn-primary addCategory"
									">اضافه</button>
									<button type = "button" class = "btn btn-secondary" data-dismiss = "modal">
										أغلاق
									</button>
								</div>

							</form>
						</div>
					</div>

				</div>
			</div>
		</div>
		<!-- /Add user Modal -->

		<!-- Edit ad Modal -->
		<div class = "modal fade" id = "exampleModal2" tabindex = "-1" role = "dialog"
		     aria-labelledby = "exampleModalLabel" aria-hidden = "true">
			<div class = "modal-dialog" role = "document">
				<div class = "modal-content">
					<div class = "modal-header">
						<h5 class = "modal-title" id = "exampleModalLabel"> تعديل اعلان : <span
								   class = "userName"></span></h5>
					</div>
					<div class = "modal-body">
						<form action = "{{route('update_ad')}}" method = "post"
						      enctype = "multipart/form-data">

							<!-- token and user id -->
							{{csrf_field()}}

							<input type = "hidden" name = "id" value = "">
							<div class = "row">

								<div class = "col-sm-6" style = "margin-top: 20px">
									<label>الاسم العربى</label>
									<input type = "text" name = "edit_name_ar" id = "address"
									       class = "form-control" placeholder = "الاسم العربى"
									       style = "margin-bottom: 10px">

								</div>
								<div class = "col-sm-6" style = "margin-top: 20px">
									<label>الاسم الانجليزى</label>
									<input type = "text" name = "edit_name_en" id = "address"
									       class = "form-control" placeholder = "الاسم الانجليزى"
									       style = "margin-bottom: 10px">

								</div>
							</div>

							<div class = "row">
								<div class = "col-sm-6">
									<input type = "number" name = "edit_cost" class = "form-control"
									       placeholder = "السعر ">

									<select name = "edit_category" id = "edit_category" class = "form-control"
									        style = "margin-bottom: 5px">
										<option>-- إختر القسم --</option>
										@foreach($categories as $category)
											<option value = "{{$category->id}}">{{$category->name_ar}}</option>
										@endforeach
									</select>
									<select name = "edit_project" id = "edit_project" class = "form-control"
									        style = "margin-bottom: 5px">
										<option value = "">--إختر المخطط --</option>
										@foreach($projects as $project)
											<option value = "{{$project->id}}">{{$project->name_ar}}</option>
										@endforeach
									</select>
								</div>

								<div class = "col-sm-6">
									<input type = "number" name = "edit_tax" class = "form-control"
									       placeholder = "الضريبة">
									<input type = "number" name = "edit_vat" class = "form-control"
									       placeholder = "السعى">
									<input type = "text" name = "edit_code" class = "form-control"
									       placeholder = "كود العرض ">
								</div>

							</div>
							<div class = "col-sm-12">
								<input type = "text" name = "edit_video" class = "form-control"
								       placeholder = "رابط الفيديو">
							</div>
							<div class = "col-sm-12">
										<textarea
											   style = "margin-bottom: 5px"
											   class = "form-control" id = "edit_desc" name = "edit_desc"
											   rows = "2"
											   placeholder = "وصف قصير"></textarea>
							</div>
							<div class = "col-sm-12">
										<textarea
											   style = "margin-bottom: 5px"
											   class = "form-control" id = "edit_component"
											   name = "edit_component"
											   rows = "2"
											   placeholder = "المكونات"></textarea>
							</div>

							<div class = "col-sm-12">
										<textarea
											   style = "margin-bottom: 5px"
											   class = "form-control" id = "edit_details"
											   name = "edit_details"
											   rows = "8"
											   placeholder = "التفاصيل"></textarea>
							</div>

							<input type = "hidden" name = "edit_lat" id = "edit_lat" readonly>


							<input type = "hidden" name = "edit_lng" id = "edit_lng" readonly>


							<div class = "col-sm-6" style = "width: 500px; height: 300px; margin-right: 30px"
							     id = "edit_map">
							</div>


							<div class = "row">
								<div class = "col-sm-12" style = "margin-top: 10px">
									<button type = "submit" class = "btn btn-primary">حفظ التعديلات</button>
									<button type = "button" class = "btn btn-secondary" data-dismiss = "modal">
										أغلاق
									</button>
								</div>
							</div>

						</form>
					</div>
				</div>
			</div>
		</div>
		<!-- /Edit user Modal -->


	</div>
	<script type = "text/javascript"
	        src = "https://maps.googleapis.com/maps/api/js?key=AIzaSyD8cUy05UAvneVcdyAUodgt2qk2I2uzHdw&libraries=places">
	</script>
	<!-- javascript -->
@section('script')
	<script type = "text/javascript"
	        src = "{{asset('dashboard/js/plugins/tables/datatables/datatables.min.js')}}"></script>
	<script type = "text/javascript" src = "{{asset('dashboard/js/plugins/forms/selects/select2.min.js')}}"></script>
	<script type = "text/javascript" src = "{{asset('dashboard/js/pages/datatables_basic.js')}}"></script>
@endsection



<script type = "text/javascript">


    function initializeEdit(ad) {

        var myLatlng = new google.maps.LatLng(ad.lat, ad.lng);
        var map;
        var myOptions = {
            zoom: 7,
            center: myLatlng,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        }
        map = new google.maps.Map(document.getElementById("edit_map"), myOptions);
        marker = new google.maps.Marker({
            position: myLatlng,
            map: map,
            draggable: true
        });

        //set values in modal inputs

        $("input[name='id']").val(ad.id)
        $("input[name='edit_name_ar']").val(ad.name_ar)
        $("input[name='edit_name_en']").val(ad.name_en)
        $("input[name='edit_cost']").val(ad.cost)
        $("input[name='edit_tax']").val(ad.tax)
        $("input[name='edit_vat']").val(ad.vat)
        $("input[name='edit_code']").val(ad.code)
        $("input[name='edit_video']").val(ad.video)
        $('#edit_desc').val(ad.desc)
        $('#edit_component').val(ad.component)
        $('#edit_details').val(ad.details)
        $("input[name='edit_lat']").val(ad.lat)
        $("input[name='edit_lng']").val(ad.lng)

        $('#edit_category option').each(function () {
            if ($(this).val() == ad.category_id) {
                $(this).attr('selected', '')
            }
        });

        $('#edit_project option').each(function () {

            if ($(this).val() == ad.project_id) {
                $(this).attr('selected', '')
            }
        });

        document.getElementById("edit_lat").value = ad.lat;
        document.getElementById("edit_lng").value = ad.lng;

        // marker refers to a global variable

        // Create the search box and link it to the UI element.
        var input = document.getElementById('edit-pac-input');
        var searchBox = new google.maps.places.SearchBox(input);
        map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);
        // Bias the SearchBox results towards current map's viewport.
        map.addListener('bounds_changed', function () {
            searchBox.setBounds(map.getBounds());
        });
        searchBox.addListener('places_changed', function () {
            var places = searchBox.getPlaces();
            if (places.length == 0) {
                return;
            }
            var bounds = new google.maps.LatLngBounds();
            places.forEach(function (place) {
                if (!place.geometry) {
                    console.log("Returned place contains no geometry");
                    return;
                }
                marker.setPosition(place.geometry.location);
                if (place.geometry.viewport) {
                    bounds.union(place.geometry.viewport);
                } else {
                    bounds.extend(place.geometry.location);
                }

                document.getElementById("edit_lat").value = place.geometry.location.lat();
                document.getElementById("edit_lng").value = place.geometry.location.lng();
            });
            map.fitBounds(bounds);
        });
        google.maps.event.addListener(marker, "dragend", function (event) {
            var clickLat = event.latLng.lat();
            var clickLon = event.latLng.lng();
            document.getElementById("edit_lat").value = clickLat.toFixed(5);
            document.getElementById("edit_lng").value = clickLon.toFixed(5);


        });
    }

    function initialize() {

        var myLatlng = new google.maps.LatLng(24.7135517, 46.67529569999999);
        var map;
        var myOptions = {
            zoom: 7,
            center: myLatlng,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        }
        map = new google.maps.Map(document.getElementById("add_map"), myOptions);
        // marker refers to a global variable
        marker = new google.maps.Marker({
            position: myLatlng,
            map: map,
            draggable: true
        });
        // Create the search box and link it to the UI element.
        var input = document.getElementById('pac-input');
        var searchBox = new google.maps.places.SearchBox(input);
        map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);
        // Bias the SearchBox results towards current map's viewport.
        map.addListener('bounds_changed', function () {
            searchBox.setBounds(map.getBounds());
        });
        searchBox.addListener('places_changed', function () {
            var places = searchBox.getPlaces();
            if (places.length == 0) {
                return;
            }
            // For each place, get the icon, name and location.
            var bounds = new google.maps.LatLngBounds();
            places.forEach(function (place) {
                if (!place.geometry) {
                    console.log("Returned place contains no geometry");
                    return;
                }
                // marker refers to a global variable
                marker.setPosition(place.geometry.location);
                if (place.geometry.viewport) {
                    // Only geocodes have viewport.
                    bounds.union(place.geometry.viewport);
                } else {
                    bounds.extend(place.geometry.location);
                }

                document.getElementById("lat").value = place.geometry.location.lat();
                document.getElementById("lng").value = place.geometry.location.lng();
            });
            map.fitBounds(bounds);
        });
        google.maps.event.addListener(marker, "dragend", function (event) {
            // get lat/lon of click
            var clickLat = event.latLng.lat();
            var clickLon = event.latLng.lng();
            // show in input box
            document.getElementById("lat").value = clickLat.toFixed(5);
            document.getElementById("lng").value = clickLon.toFixed(5);
//            var marker = new google.maps.Marker({
//                position: new google.maps.LatLng(clickLat, clickLon),
//                map: map
//            });
        });
    }

</script>

<!-- other code -->
<script type = "text/javascript">


    function addChooseFile() {
        $("input[name='avatar']").click()
    }

    //stay in current tab after reload
    $(function () {
        // for bootstrap 3 use 'shown.bs.tab', for bootstrap 2 use 'shown' in the next line
        $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
            // save the latest tab; use cookies if you like 'em better:
            localStorage.setItem('lastTab', $(this).attr('href'));
        });

        // go to the latest tab, if it exists:
        var lastTab = localStorage.getItem('lastTab');
        if (lastTab) {
            $('[href="' + lastTab + '"]').tab('show');
        }
    });
    $(function () {
        $("input[type='submit']").click(function () {
            var $fileUpload = $("input[type='file']");
            if (parseInt($fileUpload.get(0).files.length) > 11) {
                alert("أقصى عدد ممكن 11 صورة");
            }
        });
    });

</script>
<!-- /other code -->

@endsection