@extends('dashboard.layout.master')

<!-- style -->
@section('style')

@endsection
<!-- /style -->

@section('content')


	<div class = "row">
		<div class = "col-md-12">
			<div class = "panel panel-flat">
				<div class = "panel-heading">
					<h6 class = "panel-title">طلبات الحجز</h6>
					<div class = "heading-elements">
						<ul class = "icons-list">
							<li><a data-action = "reload"></a></li>
						</ul>
					</div>
				</div>
				<!-- buttons -->
				<div class = "panel-body">
					<div class = "row">
						<div class = "col-xs-4">
							<a href = "{{route('reasons')}}"
							   class = "btn bg-blue btn-block btn-float btn-float-lg openAddModal"
							   type = "button"
							   data-target = "#exampleModal"><i class = "icon-plus3"></i>
								<span>اهداف الحجز</span>
							</a>
						</div>
						<div class = "col-xs-4">
							<button class = "btn bg-purple-300 btn-block btn-float btn-float-lg" type = "button">
								<i
									   class = "icon-list-numbered"></i>
								<span>عدد الطلبات: {{count($orders)}} </span>
							</button>
						</div>
						<div class = "col-xs-4">
							<a href = "{{route('logout')}}"
							   class = "btn bg-warning-400 btn-block btn-float btn-float-lg"
							   type = "button"><i class = "icon-switch"></i> <span>خروج</span></a>
						</div>

					</div>
				</div>
				<!-- /buttons -->
				<div class = "panel-body">
					<div class = "tabbable">


						<!--  reports  -->
						<div class = "tab-pane" id = "basic-tab2">

							<table class = "table datatable-basic">
								<thead>
								<tr>
									<th>الاسم</th>
									<th>البريد الالكترونى</th>
									<th>رقم الهاتف</th>
									<th>اسم الاعلان</th>
									<th>هدف الحجز</th>
									<th>التحكم</th>
								</tr>
								</thead>
								<tbody>
								@foreach($orders as $order)
									<tr>
										<td>{{$order->name}}</td>

										<td>{{$order->user->email}}</td>

										<td>{{$order->phone}}</td>

										<td>{{$order->ads->name_ar}}</td>

										<td>{{$order->reason->name_ar}}</td>


										@if($order->accept==0)
											<td>
												<form action = "{{route('accept_order')}}"
												      method = "post" class = "display-inline-block">
													{{csrf_field()}}
													<input type = "hidden" value = "{{$order->id}}"
													       name = "id">
													<button type = "submit"
													        onclick = "return confirm('هل تريد قبول الطلب ؟');"
													        class = "btn btn-xs btn-success "
													        name = "">قبول
													</button>
												</form>

												<form action = "{{route('refuse_order')}}"
												      method = "post" class = "display-inline-block">
													{{csrf_field()}}
													<input type = "hidden" value = "{{$order->id}}"
													       name = "id">
													<button type = "submit"
													        onclick = "return confirm('هل تريد رفض الطلب ؟');"
													        class = "btn btn-xs btn-danger "
													        name = "">رفض
													</button>
												</form>
											</td>
										@elseif($order->accept==1)
											<td>تم القبول</td>
										@else
											<td>تم الرفض</td>
										@endif

									</tr>
								@endforeach
								</tbody>
							</table>

						</div>

					</div>
				</div>
			</div>

		</div>
	</div>


	<!-- javascript -->
@section('script')
	<script type = "text/javascript">
         //stay in current tab after reload
         $(function () {
             // for bootstrap 3 use 'shown.bs.tab', for bootstrap 2 use 'shown' in the next line
             $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
                 // save the latest tab; use cookies if you like 'em better:
                 localStorage.setItem('lastTab', $(this).attr('href'));
             });

             // go to the latest tab, if it exists:
             var lastTab = localStorage.getItem('lastTab');
             if (lastTab) {
                 $('[href="' + lastTab + '"]').tab('show');
             }
         });
	</script>

@endsection
<!-- /javascript -->

@endsection