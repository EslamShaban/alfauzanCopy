<style type="text/css">
    .myelements i
    {
        font-size: 46px;
        margin-top: 20%;
    }
</style>

<div class="panel panel-flat">
    <div class="panel-heading">
        <div class="row">
            <!-- Members online -->


            <!-- /members online -->
        </div>
    </div>
</div>